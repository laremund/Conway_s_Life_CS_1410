public class PatternAcorn extends Pattern {
    final private int sizeX = 9;
    final private int sizeY = 5;

    boolean[][] patternArray = new boolean[sizeX][sizeY];

    public PatternAcorn() {
        for (int i = 0; i < sizeX; i++) {
            for (int j = 0; j < sizeY; j++) {
                patternArray[i][j] = false;
            }
        }
        patternArray[2][1] = true;
        patternArray[4][2] = true;
        patternArray[1][3] = true;
        patternArray[2][3] = true;
        patternArray[5][3] = true;
        patternArray[6][3] = true;
        patternArray[7][3] = true;
    }
    @Override
    public int getSizeX() { return sizeX; }
    @Override
    public int getSizeY() { return sizeY; }
    @Override
    public boolean getCell(int x , int y) { return patternArray[x][y]; }
}
