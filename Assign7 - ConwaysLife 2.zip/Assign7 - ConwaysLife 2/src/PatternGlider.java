public class PatternGlider extends Pattern {
    // I'm not 100% sure how any of these patterns are going to turn out, but my understanding is
    // that I just have to initialize any sequence of the pattern and it will run through all of its
    // other sequences naturally
    final private int sizeX = 5;
    final private int sizeY = 5;

    boolean[][] patternArray = new boolean[sizeX][sizeY];

    public PatternGlider() {
        for (int i = 0; i < sizeX; i++) {
            for (int j = 0; j < sizeY; j ++) {
                patternArray[i][j] = false;
            }
        }
        patternArray[2][1] = true;
        patternArray[3][2] = true;
        patternArray[1][3] = true;
        patternArray[2][3] = true;
        patternArray[3][3] = true;
    }
    @Override
    public int getSizeX() { return sizeX; }
    @Override
    public int getSizeY() { return sizeY; }
    @Override
    public boolean getCell(int x , int y) { return patternArray[x][y]; }
}
