public class PatternBlock extends Pattern {

    final private int sizeX = 4;
    final private int sizeY = 4;

    boolean[][] patternArray = new boolean[sizeX][sizeY];

    public PatternBlock() {
        for (int i = 0; i < sizeX; i++) {
            for (int j = 0; j < sizeY; j++) {
                if (i == 0 || j == 0 || i == sizeX - 1 || j == sizeY - 1) {
                    patternArray[i][j] = false;
                } else {
                    patternArray[i][j] = true;
                }
            }
        }
    }

    @Override
    public int getSizeX() { return sizeX; }

    @Override
    public int getSizeY() { return sizeY; }

    @Override
    public boolean getCell(int x , int y) { return patternArray[x][y]; }
}
