public class PatternBlinker extends Pattern {

    final private int sizeX = 5;
    final private int sizeY = 5;

    boolean[][] patternArray = new boolean[sizeX][sizeY];

    public PatternBlinker() {
        for (int i = 0; i < sizeX; i++) {
            for (int j = 0; j < sizeY; j++) {
                if (i == 2 && (j != 0 && j != sizeY - 1)) {
                    patternArray[i][j] = true;
                } else {
                    patternArray[i][j] = false;
                }
            }
        }
    }
    @Override
    public int getSizeX() { return sizeX; }
    @Override
    public int getSizeY() { return sizeY; }
    @Override
    public boolean getCell(int x , int y) { return patternArray[x][y]; }
}
