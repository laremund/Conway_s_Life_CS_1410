import java.lang.reflect.Array;

public class LifeSimulator {

    // Note: I am allowed to add any private fields or methods you like, but cannot modify the
    // public interface in any way
    private int sizeX;
    private int sizeY;
    // Below, I'm not sure if this was ok to do, I've never seen an array created empty like this and
    // then intialized in a constructor like this
    private boolean[][] lifeGrid;
    // Note: Cells on the edge of the field should count cells past the edge (those that don't
    // exist) as dead cells; in other words, they don't count.
        // If I want to or think that it's easier, I can "wrap" and count the cells from the other
        // edge

    // sizeX and sizeY indicate the size of the world. "the code I have provided passes these values
    // into the LifeSimulator constructor. In the constructor, an internal 2d array (the grid) is
    // created of that size, this is the grid used to maintain the state of the simulation
    public LifeSimulator(int sizeX, int sizeY) {
        // IMPORTANT the lifeGrid below has been edited to accomodate the two extra columns and rows
        // of dead cells
        lifeGrid = new boolean[sizeX + 2][sizeY + 2];
        // These variables below are the true sizeX and sizeY, not the +2 modified ones
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        // IMPORTANT the below loop has been edited for +2 column and row implementation
        for (int i = 0; i < sizeX + 2; i++) {
            for (int j = 0; j < sizeY + 2; j++) {
                lifeGrid[i][j] = false;
            }
        }
    }

    // The two below methods return the size of the world
    public int getSizeX() { return sizeX; }
    public int getSizeY() { return sizeY; }

    // Returns true if the world cell is alive, false otherwise
    boolean getCell(int x, int y) { return lifeGrid[x][y]; }

    // Adds the pattern to the world, with the upper left corner beginning at startX and start Y.
    // Adding a pattern means copying the cells from the pattern into the internal grid representation
    // of the simulator. You don't keep references to the original patterns, you copy the cell values
    // into the simulator. Multiple patterns can be added by repeatedly calling this method
    public void insertPattern(Pattern pattern, int startX, int startY) {
        // To put the pattern onto the LifeSimulator, start at startX and startY in the LifeSimulator
        // array, and then for the width and height of the pattern, get each cell to tell whether it
        // is alive or dead

        // Edited for the dead border +2 columns +2 row implementation
        for (int i = startX; i < startX + pattern.getSizeX(); i++) {
            for (int j = startY; j < startY + pattern.getSizeY(); j++) {
                // I need a conditional to check whether the cell that I'm checking is within the workable
                // area or in the dead border. Pretty sure this isn't going to work because the continue
                // statement is oddly faded out
                if (i == 0 || i >= sizeX + 1 || j == 0 || j >= sizeY + 1) {
                    continue;
                } else {
                    // I'm not sure if the below code still works with the dead border implementation
                    lifeGrid[i][j] = pattern.getCell(i - startX, j - startY);
                }
            }
        }

    }

    // Performs a single step update of the world, following the four rules specified in the wiki
    // article. The following steps provide an overview for how to do an update:
    public void update() {
        // 1. Make a new grid (array) that is the same size as the current grid
            // > You'll have a reference called something like 'original' and a reference called
            // 'updated'. Where 'original' refers to the current grid state and 'updated' refers to
            // the new grid you just created
        boolean[][] lifeGridUpdated = new boolean[sizeX + 2][sizeY + 2];
        // 2. For each cell in the original grid, use the 4 rules to decide the state of that cell in
        // the updated grid
            // I have two ideas for how to deal with the issue of treating cells off the edge of the
            // grid as dead:
                // 1. Make the grid two columns thicker and 2 rows taller, the top-most
                // and bottom-most rows being composed entirely of dead cells, likewise with the left
                // and right-most columns;
                // 2. Do what he said was hard and do the sort of pac-man-esque reflect thing where
                // checking a cell outside the given area checks the cell on the opposite side
        for (int i = 0; i < sizeX + 2; i++) {
            for (int j = 0; j < sizeY + 2; j++) {
                int liveCount = 0;
                if (i == 0 || i >= sizeX + 1 || j == 0 || j >= sizeY + 1) {
                    continue;
                }
                if (lifeGrid[i - 1][j + 1]) { // Top Left
                    liveCount++;
                } if (lifeGrid[i][j + 1]) { // Top middle
                    liveCount++;
                } if (lifeGrid[i + 1][j + 1]) { // Top right
                    liveCount++;
                } if (lifeGrid[i - 1][j]) { // Middle left
                    liveCount++;
                } if (lifeGrid[i + 1][j]) { // Middle right
                    liveCount++;
                } if (lifeGrid[i - 1][j - 1]) { // Bottom left
                    liveCount++;
                } if (lifeGrid[i][j - 1]) { // Bottom middle
                    liveCount++;
                } if (lifeGrid[i + 1][j - 1]) { // Bottom right
                    liveCount++;
                }
                // 3. Put the value of the updated cell state in the updated grid. You never change any of the
                // cell values in the original grid, you only read from it, always writing the updated values in
                // the updated grid
                    // If the cell in the og grid was alive and has 2 or 3 live neighbors,
                    // it will survive and the updated grid will have a live cell at that location
                if (lifeGrid[i][j] && (liveCount == 2 || liveCount == 3)) {
                    lifeGridUpdated[i][j] = true;
                    // If the cell in the og grid was dead and exactly 3 of its neighbors are alive,
                    // it comes back to life in the updated grid
                } else if (!lifeGrid[i][j] && (liveCount == 3)) {
                    lifeGridUpdated[i][j] = true;
                    // If:
                    // 1. The cell was alive and had less than 2 live neighbors, or more than 3
                    // neighbors, it dies from under or overpopulation
                    // 2. The cell was dead and had less than or more than three neighbors, it remains dead
                } else {
                    lifeGridUpdated[i][j] = false;
                }
            }
        }
        // 4. When finished going through all the cells and setting their values in the updated grid,
        // set the reference of 'original' to refer to the 'updated' grid
        lifeGrid = lifeGridUpdated;
    }

    // Idk where to put this note, so I'm going to put it here:
    // Your program will run for some number of steps for the animation for your demonstration. You
    // can use a single counted for loop for this, but you'll want to pause for a little bit between
    // each animation step. You can use a line of code like the following to pause for some number
    // of milliseconds

    // Thread.sleep(50); This will sleep for 50 milliseconds

    // To add a pattern to your simulator, for your animation demonstration, you'll have code something
    // along these lines

    // LifeSimulator mySim = new LifeSimulator();
    // mySim.insertPattern(new PatternBlock(), 0, 0);
    // mySim.insertPattern(new PatternBlinker(), 0, 10);
    // mySim.insertPattern(new PatternGlider(), 15, 15);

    // Then go into an animation loop or several loops. You can have multiple loops, with each
    // demonstrating something different. You can insert patterns during the animation, etc.
}